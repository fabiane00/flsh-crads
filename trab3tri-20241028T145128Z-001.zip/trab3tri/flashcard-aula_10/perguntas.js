criaCartao(
    '1',
    'quem sou eu?',
    'fabiane eloise aluna do morski'
)

criaCartao(
    '2',
    'minha familia?',
    'mãe,irmã mais velha e irmã mais nova'
)

criaCartao(
    '3',
    'Onde eu moro?',
    'carvalhos não e muito longe 5 kms do pinhão '
)
criaCartao(
    '4',
    'onde estudo?',
    'morski'
)

criaCartao(
    '5',
    'minha turma?',
    'somos todos amigo, alguns são meio desagradavéis'
)

criaCartao(
    '6',
    'faculdade?',
    'direito (advogada)'
)
criaCartao(
    '7',
    'minha cidade?',
    'cidade pequena 34 mil bitantes eu acho'
)

criaCartao(
    '8',
    'meu sonho?',
    'ser feliz com a minha familia'
)

